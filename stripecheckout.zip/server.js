"use strict";

const express = require("express");
const cors = require("cors");
const { Stripe } = require("stripe");
require("dotenv").config();
const mysql = require("mysql2/promise");

const app = express();
app.use(express.static("public")); // serve success.html here
app.use(cors());
app.use(express.json());

const stripe = new Stripe(process.env.STRIPE_API_KEY);
const PORT = 4242;

// MySQL pool
const db = mysql.createPool({
  host: "localhost",
  user: "root",       // replace with your MySQL user
  password: "dbpass",
  database: "stripe_payments"
});

// Create Stripe price
async function createPrice(amount, name) {
  return await stripe.prices.create({
    currency: "eur",
    unit_amount: Math.round(amount * 100),
    product_data: { name },
  });
}

// Texts for EN/PT
const TEXTS = {
  en: {
    order: "Your order at Restaurant",
    tipPercent: (p) => `Tip ${p}%`,
    tipFixed: (amount) => `Tip €${amount}`,
    invalidAmount: "Incorrect order amount",
    serverError: "Error when creating Checkout Session",
  },
  pt: {
    order: "Seu pedido no Restaurante",
    tipPercent: (p) => `Gorjeta ${p}%`,
    tipFixed: (amount) => `Gorjeta €${amount}`,
    invalidAmount: "Valor do pedido incorreto",
    serverError: "Erro ao criar sessão de checkout",
  },
};

// POST /api/Stripe/payment
app.post("/api/Stripe/payment", async (req, res) => {
  const { amount, tipPercent = 0, tipFixed = 0, lang = "en" } = req.body;
  const texts = TEXTS[lang] || TEXTS.en;

  if (!amount || amount <= 0) {
    return res.status(400).json({ error: texts.invalidAmount });
  }

  try {
    // Main order
    const mainPrice = await createPrice(amount, texts.order);
    const lineItems = [{ price: mainPrice.id, quantity: 1 }];

    // Percentage tip
    if (tipPercent > 0) {
      const tipPrice = await createPrice(amount * tipPercent / 100, texts.tipPercent(tipPercent));
      lineItems.push({ price: tipPrice.id, quantity: 1 });
    }

    // Fixed tip
    if (tipFixed > 0) {
      const tipPriceFixed = await createPrice(tipFixed, texts.tipFixed(tipFixed));
      lineItems.push({ price: tipPriceFixed.id, quantity: 1 });
    }

    // Create Stripe Payment Link
    const paymentLink = await stripe.paymentLinks.create({
      line_items: lineItems,
      restrictions: { completed_sessions: { limit: 1 } },
      after_completion: {
        type: "redirect",
        redirect: { url: "http://192.168.0.31:4242/success.html" }
      }
    });

    // Calculate total
    const tip = (tipPercent > 0 ? (amount * tipPercent) / 100 : 0) + (tipFixed > 0 ? tipFixed : 0);
    const total = amount + tip;

    // Save to DB
    await db.query(
      "INSERT INTO payments (amount, tip, total, lang, stripe_url) VALUES (?, ?, ?, ?, ?)",
      [amount.toFixed(2), tip.toFixed(2), total.toFixed(2), lang, paymentLink.url]
    );

    res.json({ url: paymentLink.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: texts.serverError, stripe_error: err.message });
  }
});

// GET /api/last-payment
app.get("/api/last-payment", async (req, res) => {
  try {
    const [rows] = await db.query(
      "SELECT * FROM payments ORDER BY created_at DESC LIMIT 1"
    );
    if (rows.length === 0) return res.json({ error: "No payments found" });
    res.json(rows[0]);
  } catch (err) {
    console.error("DB error:", err);
    res.status(500).json({ error: "Database error" });
  }
});

app.listen(PORT, () => {
  console.log(`Stripe server running on http://localhost:${PORT}`);
});

