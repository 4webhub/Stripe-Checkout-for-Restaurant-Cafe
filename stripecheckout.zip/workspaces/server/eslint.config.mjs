import globals from "globals";
import pluginJs from "@eslint/js";
import tseslint from "typescript-eslint";

/** @type {import('eslint').Linter.Config[]} */
export default [
	{
		ignores: ["dist", "eslint.config.mjs"]
	},
	{
		files: ["**/*.{js,mjs,cjs,ts}"]
	},
	{
		languageOptions: {
			globals: {
				...globals.node,
				...globals.es2025
			},
			parserOptions: {
				project: true,
				tsconfigRootDir: import.meta.dirname
			}
		}
	},
	pluginJs.configs.recommended,
	...tseslint.configs.recommended,
	{
		rules: {
			"semi": ["error", "always"],
			"indent": ["error", "tab"],
			"quotes": ["warn", "double"]
		}
	}
];
