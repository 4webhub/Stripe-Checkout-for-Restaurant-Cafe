import { readFileSync } from "fs";
import { ServerOptions } from "https";
import { join } from "node:path/win32";

export function readServerCertificate(): ServerOptions {
	const certificate: ServerOptions = {};
	
	const credentialsPath = join(process.cwd(), "/credentials");
	const keyPath = join(credentialsPath, "key.pem");
	const certPath = join(credentialsPath, "cert.pem");
	
	certificate.key = readFileSync(keyPath, { encoding: "utf8" });
	certificate.cert = readFileSync(certPath, { encoding: "utf8" });
	
	return certificate;
}

export function readPaymentFlavorText(): string {
	return process.env["PAYMENT_FLAVOR_TEXT"] || "Payment via terminal";
}
