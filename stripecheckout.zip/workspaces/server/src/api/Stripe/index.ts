import { Router } from "express";
import { stripeInstance } from "@/services/Stripe";
import { readPaymentFlavorText } from "@/config";

const PAYMENT_FLAVOR_TEXT = readPaymentFlavorText();

export const stripeApiRouter = Router()
	.post("/payment", (req, res) => {
		void (async () => {
			const value = req.body.value as unknown;
			
			if(typeof value === "undefined" || typeof value !== "number") {
				return res.status(400).json({
					error: "Invalid value submitted."
				});
			}
			
			try {
				const price = await stripeInstance.prices.create({
					currency: "eur",
					unit_amount: Math.floor(value * 100),
					product_data: {
						name: PAYMENT_FLAVOR_TEXT
					}
				});
				
				const paymentLink = await stripeInstance.paymentLinks.create({
					line_items: [
						{
							price: price.id,
							quantity: 1
						}
					],
					restrictions: {
						completed_sessions: {
							 limit: 1
						}
					}
				});
				
				console.log(`Payment request for ${value}€ made.`);
				
				return res.status(303).json({
					url: paymentLink.url
				});
			} catch(error) {
				res.status(500).json({
					error: "Something went wrong while generating a payment link. Please try again!"
				});
				
				console.log(error);
			}
		})();
	});
