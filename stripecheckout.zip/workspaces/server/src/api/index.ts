import { Router } from "express";
import { stripeApiRouter } from "@/api/Stripe";

export const apiRouter = Router()
	.use("/stripe", stripeApiRouter);
