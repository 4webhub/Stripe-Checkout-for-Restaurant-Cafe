import express, { Express } from "express";
import { existsSync } from "node:fs";
import { join } from "node:path/win32";
import { renderFile } from "pug";

export function useViewEngine(app: Express) {
	const htdocsPath = join(process.cwd(), "/htdocs");
	if(existsSync(htdocsPath)) {
		const assetsPath = join(htdocsPath, "/assets");
		const faviconPath = join(htdocsPath, "/favicon.ico");
		
		app.use("/assets", express.static(assetsPath));
		app.use("/favicon.ico", express.static(faviconPath));
		
		app.engine("html", renderFile);
		app.set("view engine", "html");
		app.set("views", htdocsPath);
		
		app
			.get(["/", "/code"], (req, res) => {
				return res.render("index.html");
			})
			.get("*", (req, res) => {
				return res.redirect("/");
			});
	} else {
		console.log("Warning, missing htdocs!!");
		app.get("*", (req, res) => {
			return res.status(404).send("<p>This server is running in API-only mode!</p>");
		});
	}
}
