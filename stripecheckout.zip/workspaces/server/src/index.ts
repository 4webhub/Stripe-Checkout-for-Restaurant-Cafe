import "dotenv/config";
import express from "express";
import { createServer } from "https";
import { readServerCertificate } from "@/config";
import { apiRouter } from "@/api";
import { setupStripeService } from "@/services/Stripe";
import helmet from "helmet";
import { useViewEngine } from "@/middleware/ViewEngine";

void (async () => {
	try {
		const app = express();
		
		app.use(helmet());
		app.use(express.json());
		
		await setupStripeService();
		
		app.use("/api", apiRouter);
		
		useViewEngine(app);
		
		const serverOptions = readServerCertificate();
		const httpsServer = createServer(serverOptions, app).listen(8443);
		
		httpsServer.on("listening", () => {
			console.log(
				"Payment link generator server running!"
				+ "\nhttps://localhost:8443"
			);
		});
	} catch(error) {
		console.log("Couldn't start server.\n" + error);
	}
})();
