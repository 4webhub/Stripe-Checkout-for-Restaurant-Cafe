import { Stripe } from "stripe";

export let stripeInstance: Stripe;

export async function setupStripeService() {
	const apiKey = process.env["STRIPE_API_KEY"];
	if(typeof apiKey === "undefined") { throw new Error("No Stripe API key was specified."); }
	
	const instance = new Stripe(apiKey);
	
	try {
		await instance.products.list({ limit: 1 });
		stripeInstance = instance;
	// eslint-disable-next-line @typescript-eslint/no-unused-vars
	} catch(error) {
		console.log("Invalid Stripe API key provided.");
		process.exit(-1);
	}
}
