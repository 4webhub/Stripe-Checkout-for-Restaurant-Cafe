import pluginVue from "eslint-plugin-vue";
import vueTsEslintConfig from "@vue/eslint-config-typescript";
import oxlint from "eslint-plugin-oxlint";

export default [
	{
		name: "app/files-to-lint",
		files: ["**/*.{ts,mts,tsx,vue}"]
	},
	{
		name: "app/files-to-ignore",
		ignores: ["**/dist/**", "**/dist-ssr/**", "**/coverage/**"]
	},
	...pluginVue.configs["flat/essential"],
	...vueTsEslintConfig(),
	oxlint.configs["flat/recommended"],
	{
		rules: {
			"indent": ["error", "tab"],
			"semi": ["error", "always"],
			"quotes": ["warn", "double"]
		}
	},
	{
		files: ["**/*.vue"],
		rules: {
			"indent": "off",
			"vue/script-indent": ["error", "tab", {"baseIndent": 1}],
			"vue/html-indent": ["error", "tab"],
			"vue/html-self-closing": "off",
			"vue/singleline-html-element-content-newline": "off"
		}
	}
];
