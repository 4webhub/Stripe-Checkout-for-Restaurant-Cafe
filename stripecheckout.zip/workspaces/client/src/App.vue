<script lang="ts" setup>
	import { RouterView } from "vue-router";
</script>

<template>
	<RouterView/>
</template>
