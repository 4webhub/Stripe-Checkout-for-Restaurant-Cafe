<script lang="ts" setup>
	import { onMounted, ref } from "vue";
	import router from "@/router";

	const moneyValue = defineModel<string>();
	const errorText = ref<string>("");

	onMounted(() => moneyValue.value = "0");

	async function submit(action: "redirect" | "qrcode") {
		errorText.value = "";

		if(typeof moneyValue.value === "undefined") { return errorText.value = "Input a number."; }

		const parsedValue = parseFloat(moneyValue.value as string);
		if(isNaN(parsedValue)) { return errorText.value = "Input a number."; }
		if(parsedValue <= 0) { return errorText.value = "Input a positive number."; }

		try {
			const response = await fetch("/api/stripe/payment", {
				method: "POST",
				headers: {
					"Content-Type": "application/json"
				},
				body: JSON.stringify({
					value: parsedValue
				})
			});

			const url = (await response.json()).url;

			switch(action) {
			case "redirect": {
				document.location.href = url;
				break; }
			case "qrcode": {
				await router.push(`/code?url=${url}`);
				break; }
			}
		} catch(error) {

		}
	}
</script>

<template>
	<main>
		<section class="payment-creator-holder">
			<h1>Insert payment amount</h1>
			<span class="money-input">
				<input type="number" min="0.00" step="0.01" class="money-input" v-model="moneyValue">€
			</span>
			<span class="button-group">
				<button type="button" class="submit-button qr-code" @click="submit('qrcode')">
					<i class="bi-qr-code-scan"></i>
				</button>
				<button type="button" class="submit-button redirect" @click="submit('redirect')">
					<i class="bi-arrow-right"></i>
				</button>
			</span>
			<span class="error-text">
				{{ errorText }}
			</span>
		</section>
	</main>
</template>

<style scoped lang="scss">
	main {
		display: flex;

		width: 100%;
		height: 100vh;
	}

	.error-text {
		color: red;
		font-weight: bold;
	}

	.payment-creator-holder {
		display: flex;
		flex-direction: column;
		gap: 0.5em;

		margin: auto;
		padding: 0.5em;
	}

	.payment-creator-holder h1 {
		align-self: center;
		font-weight: bold;
	}

	.payment-creator-holder .money-input {
		display: flex;
		align-self: center;

		width: 5em;

		justify-content: center;
		align-items: center;
	}

	.payment-creator-holder .money-input input {
		outline: none;
		margin-right: 0.25em;

		padding: 0.2em;

		border: 2px solid #a1a1aa;
		border-radius: 4px;
	}

	.button-group {
		display: flex;

		width: 100%;
		height: 5em;

		margin-top: 1em;

		gap: 1em;
	}

	.submit-button {
		flex-grow: 1;

		color: white;
		background-color: #15803d;

		border-radius: 8px;
		font-size: xx-large;

		transition: background-color 150ms;

		&:hover {
			background-color: #16a34a;
		}

		&:active {
			background-color: #15803d;
		}
	}
</style>
