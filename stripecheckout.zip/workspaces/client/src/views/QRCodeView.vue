<script setup lang="ts">
	import router from "@/router";
	import { onMounted } from "vue";
	import { toCanvas } from "qrcode";

	onMounted(async () => {
		const urlParam = router.currentRoute.value.query.url as unknown;
		if(typeof urlParam !== "undefined" && typeof urlParam === "string") {
			const canvasHolder = document.getElementById("qrcode-canvas-holder") as HTMLAnchorElement;
			canvasHolder.href = urlParam;
			toCanvas(urlParam, { errorCorrectionLevel: "low", scale: 10 }, (error, canvas) => {
				canvasHolder.appendChild(canvas);
			});
		}
	});
</script>

<template>
	<main>
		<h1>Scan or tap QR code to proceed with payment</h1>
		<a id="qrcode-canvas-holder"></a>
		<RouterLink to="/">Go back</RouterLink>
	</main>
</template>

<style scoped lang="scss">
	main {
		display: flex;
		flex-direction: column;

		width: 100%;
		height: 100vh;

		justify-content: center;
		align-items: center;
	}

	h1 {
		font-weight: bold;
	}
</style>
