import { $ as _ } from "execa";
import { cpSync, mkdirSync, writeFileSync } from "node:fs";
import { readFileSync } from "fs";

const $ = _({stdin: "inherit", stdout: "inherit"});

void (async () => {
	await $`rimraf dist`;
	await $`yarn workspaces foreach -Apt run build`;
	
	mkdirSync("./dist");
	cpSync("./workspaces/server/dist", "./dist", {recursive: true});
	cpSync("./workspaces/client/dist", "./dist/htdocs", {recursive: true});
	cpSync("./workspaces/server/.env", "./dist/.env");
	cpSync("./workspaces/server/credentials", "./dist/credentials", {recursive: true});
	
	writeFileSync("./dist/yarn.lock", "");
	writeFileSync("./dist/.yarnrc.yml", "nodeLinker: node-modules", {encoding: "utf8"});
	const packageContents = JSON.parse(readFileSync("./workspaces/server/package.json", {encoding: "utf8"}));
	writeFileSync("./dist/package.json", JSON.stringify({dependencies: packageContents.dependencies}), {encoding: "utf8"});
	await $`yarn --cwd ./dist install`;
})();
