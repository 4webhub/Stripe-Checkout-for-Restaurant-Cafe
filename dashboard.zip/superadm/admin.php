<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

if (empty($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit;
}
require 'config.php';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("DB Connection failed: " . $conn->connect_error);
}

// === ФИЛЬТРЫ ===
$where = []; $params = [];
if (!empty($_GET['lang'])) { $where[] = "lang = ?"; $params[] = $_GET['lang']; }
if (!empty($_GET['date_from'])) { $where[] = "DATE(created_at) >= ?"; $params[] = $_GET['date_from']; }
if (!empty($_GET['date_to'])) { $where[] = "DATE(created_at) <= ?"; $params[] = $_GET['date_to']; }
if (isset($_GET['tip_min']) && $_GET['tip_min'] !== '') { $where[] = "tip >= ?"; $params[] = $_GET['tip_min']; }
if (isset($_GET['tip_max']) && $_GET['tip_max'] !== '') { $where[] = "tip <= ?"; $params[] = $_GET['tip_max']; }

$sql = "SELECT * FROM payments";
if ($where) $sql .= " WHERE " . implode(" AND ", $where);
$sql .= " ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);
if ($params) {
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin • Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <style>
    .sidebar-active { @apply bg-indigo-700 text-white; }
    .sidebar-hover:hover { @apply bg-indigo-500 text-white; }
    #mobileMenu { transition: transform 0.3s ease-in-out; }
    #mobileMenu.closed { transform: translateX(-100%); }
  </style>
</head>
<body class="h-full bg-gray-100 flex font-sans">

  <div id="mobileMenu" class="fixed inset-y-0 left-0 z-50 w-64 bg-indigo-600 text-white flex flex-col shadow-2xl closed lg:hidden">
    <div class="p-6 border-b border-indigo-700">
      <h1 class="text-2xl font-bold flex items-center gap-3">
        <i class="fas fa-credit-card"></i> Restaurant
      </h1>
    </div>
    <nav class="flex-1 px-4 py-6 space-y-1">
      <a href="admin.php" class="flex items-center gap-3 px-4 py-3 rounded-lg sidebar-active transition">
        <i class="fas fa-tachometer-alt"></i> Dashboard
      </a>
      <a href="admin_change_password.php" class="flex items-center gap-3 px-4 py-3 rounded-lg sidebar-hover transition">
        <i class="fas fa-key"></i> Change Password
      </a>
    </nav>
    <div class="p-4 border-t border-indigo-700">
      <form action="admin_logout.php" method="post">
        <button type="submit" class="w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 py-3 rounded-lg font-medium">
          <i class="fas fa-sign-out-alt"></i> Logout
        </button>
      </form>
    </div>
  </div>

  <div class="flex-1 flex flex-col w-full">

    <!-- topbar -->
    <header class="bg-white shadow-sm border-b border-gray-200 px-4 sm:px-8 py-4 flex justify-between items-center">
      <div class="flex items-center gap-4">
        <!-- burger -->
        <button id="menuToggle" class="lg:hidden text-gray-700 text-2xl">
          <i class="fas fa-bars"></i>
        </button>
        <h2 class="text-2xl sm:text-3xl font-bold text-gray-800">Payments Overview</h2>
      </div>
      <div class="text-sm text-gray-500">
        <i class="fas fa-clock"></i> Auto-refresh in 60s
      </div>
    </header>

    <div class="flex flex-1 overflow-hidden">
      <aside class="hidden lg:flex lg:flex-col w-64 bg-indigo-600 text-white shadow-xl">
        <div class="p-6 border-b border-indigo-700">
          <h1 class="text-2xl font-bold flex items-center gap-3">
            <i class="fas fa-credit-card"></i> Restaurant
          </h1>
          <p class="text-indigo-200 text-sm mt-1">Payment Admin</p>
        </div>

        <nav class="flex-1 px-4 py-6 space-y-1">
          <a href="admin.php" class="flex items-center gap-3 px-4 py-3 rounded-lg sidebar-active transition">
            <i class="fas fa-tachometer-alt"></i> Dashboard
          </a>
          <a href="admin_change_password.php" class="flex items-center gap-3 px-4 py-3 rounded-lg sidebar-hover transition">
            <i class="fas fa-key"></i> Change Password          
         </a>
        </nav>

        <div class="p-4 border-t border-indigo-700 mt-auto">
          <form action="admin_logout.php" method="post" class="w-full">
            <button type="submit" class="w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 py-3.5 rounded-lg font-medium transition shadow-lg">
              <i class="fas fa-sign-out-alt"></i> Logout
            </button>
          </form>
        </div>
      </aside>

      <!-- content -->
      <main class="flex-1 p-4 sm:p-8 overflow-auto">
        <!-- filters -->
        <div class="bg-white rounded-xl shadow-lg p-5 mb-6">
          <h3 class="text-xl font-semibold mb-4 text-gray-800 flex items-center gap-2">
            <i class="fas fa-filter"></i> Filters
          </h3>
          <form method="GET" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4">
            <select name="lang" class="border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-indigo-500">
              <option value="">All Languages</option>
              <option value="en" <?= ($_GET['lang'] ?? '') === 'en' ? 'selected' : '' ?>>English</option>
              <option value="pt" <?= ($_GET['lang'] ?? '') === 'pt' ? 'selected' : '' ?>>Português</option>
            </select>
            <input type="date" name="date_from" value="<?= $_GET['date_from'] ?? '' ?>" class="border border-gray-300 rounded-lg px-4 py-3">
            <input type="date" name="date_to" value="<?= $_GET['date_to'] ?? '' ?>" class="border border-gray-300 rounded-lg px-4 py-3">
            <input type="number" step="0.01" name="tip_min" value="<?= $_GET['tip_min'] ?? '' ?>" placeholder="Tip min (€)" class="border border-gray-300 rounded-lg px-4 py-3">
            <input type="number" step="0.01" name="tip_max" value="<?= $_GET['tip_max'] ?? '' ?>" placeholder="Tip max (€)" class="border border-gray-300 rounded-lg px-4 py-3">
            <div class="flex gap-3 col-span-1 sm:col-span-2 lg:col-span-1">
              <button type="submit" class="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-lg shadow transition">
                Apply
              </button>
              <a href="admin.php" class="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-3 px-6 rounded-lg text-center shadow transition">
                Reset
              </a>
            </div>
          </form>
        </div>

        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
          <div class="overflow-x-auto">
            <table class="w-full min-w-[900px]">
              <thead class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
                <tr>
                  <th class="px-4 py-3 text-left text-sm">ID</th>
                  <th class="px-4 py-3 text-right text-sm">Amount</th>
                  <th class="px-4 py-3 text-right text-sm">Tip</th>
                  <th class="px-4 py-3 text-right text-sm font-bold">Total</th>
                  <th class="px-4 py-3 text-center text-sm">Currency</th> <!-- new -->
                  <th class="px-4 py-3 text-center text-sm">Lang</th>
                  <th class="px-4 py-3 text-sm">Full Name</th> <!-- new -->
                  <th class="px-4 py-3 text-sm">Email</th> <!-- new -->
                  <th class="px-4 py-3 text-sm">Payment ID</th>
                  <th class="px-4 py-3 text-center text-sm">Link</th>
                  <th class="px-4 py-3 text-center text-sm">Created</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-gray-200">
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr class="hover:bg-gray-50 transition text-sm">
                  <td class="px-4 py-3 font-medium">#<?= $row['id'] ?></td>
                  <td class="px-4 py-3 text-right">€<?= number_format($row['amount'], 2) ?></td>
                  <td class="px-4 py-3 text-right text-green-600 font-semibold">+€<?= number_format($row['tip'], 2) ?></td>
                  <td class="px-4 py-3 text-right font-bold text-indigo-600">€<?= number_format($row['total'], 2) ?></td>
                  <td class="px-4 py-3 text-center font-mono text-sm uppercase"><?= htmlspecialchars($row['currency'] ?? 'EUR') ?></td>
                  <td class="px-4 py-3 text-center">
                    <span class="px-2 py-1 rounded-full text-xs font-bold <?= $row['lang']=='pt'?'bg-yellow-100 text-yellow-800':'bg-blue-100 text-blue-800' ?>">
                      <?= strtoupper($row['lang']) ?>
                    </span>
                  </td>
                   <td class="px-4 py-3 max-w-xs truncate" title="<?= htmlspecialchars($row['full_name'] ?? '') ?>">
                     <?= htmlspecialchars($row['full_name'] ?? '') ?>
                   </td>
                   <td class="px-4 py-3 max-w-xs truncate" title="<?= htmlspecialchars($row['email'] ?? '') ?>">
                  <a href="mailto:<?= htmlspecialchars($row['email'] ?? '') ?>" class="text-indigo-600 hover:underline">
                  <?= htmlspecialchars($row['email'] ?? '') ?>
                  </a>
                  </td>
                  <td class="px-4 py-3 font-mono text-xs text-gray-600 truncate max-w-32">
                    <?= htmlspecialchars($row['stripe_payment_intent_id'] ?? '—') ?>
                  </td>
                  <td class="px-4 py-3 text-center">
                    <?php if ($row['stripe_url']): ?>
                      <a href="<?= htmlspecialchars($row['stripe_url']) ?>" target="_blank" class="inline-block bg-gradient-to-r from-green-500 to-emerald-600 text-white px-3 py-1.5 rounded-lg text-xs font-medium hover:shadow-lg transition">
                        Open
                      </a>
                    <?php else: ?>
                      <span class="text-gray-400">—</span>
                    <?php endif; ?>
                  </td>
                  <td class="px-4 py-3 text-center text-xs text-gray-600">
                    <?= date('d/m H:i', strtotime($row['created_at'])) ?>
                  </td>
                </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>

    <footer class="bg-white border-t border-gray-200 px-6 py-4 text-center text-gray-500 text-sm">
      © <?= date('Y') ?> Restaurant • All rights reserved
    </footer>
  </div>

  <!-- Overlay -->
  <div id="overlay" class="fixed inset-0 bg-black/50 z-40 hidden lg:hidden"></div>

  <script>
    const menuToggle = document.getElementById('menuToggle');
    const mobileMenu = document.getElementById('mobileMenu');
    const overlay = document.getElementById('overlay');

    menuToggle?.addEventListener('click', () => {
      mobileMenu.classList.toggle('closed');
      overlay.classList.toggle('hidden');
    });

    overlay.addEventListener('click', () => {
      mobileMenu.classList.add('closed');
      overlay.classList.add('hidden');
    });

    setTimeout(() => location.reload(), 60000);
  </script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
