<?php
ob_start();
session_start();

if (empty($_SESSION['admin_logged_in'])) {
    header('Location: ../admin_login.php');
    exit;
}

require 'config.php'; 

// DEMO MODE
define('DEMO_MODE', true);

$err = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && DEMO_MODE) {
    $success = 'Password changed successfully! (demo mode)';
    // Или честно:
    $err = 'Password change is disabled in demo version';
    
    // SweetAlert
    $show_demo_alert = true;
}

$err     = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = $_SESSION['admin_username'] ?? '';
    $current  = $_POST['current_password'] ?? '';
    $new1     = $_POST['new_password'] ?? '';
    $new2     = $_POST['confirm_password'] ?? '';

    // Валидация
    if (!$current || !$new1 || !$new2) {
        $err = 'Please fill all fields.';
    } elseif ($new1 !== $new2) {
        $err = 'New passwords do not match.';
    } elseif (strlen($new1) < 8) {
        $err = 'Password must be at least 8 characters.';
    } else {
        // Подключаемся к БД
        $conn = new mysqli($host, $user, $pass, $db);
        if ($conn->connect_error) {
            $err = 'Database connection failed.';
        } else {
            // 1. Получаем текущий хеш
            $stmt = $conn->prepare("SELECT password_hash FROM admins WHERE username = ? LIMIT 1");
            if (!$stmt) {
                $err = 'Database error (prepare select).';
            } else {
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result();
                $row = $result->fetch_assoc();
                $stmt->close();

                if (!$row) {
                    $err = 'User not found.';
                } elseif (!password_verify($current, $row['password_hash'])) {
                    $err = 'Current password is incorrect.';
                } else {
                    // 2. Обновляем пароль
                    $newHash = password_hash($new1, PASSWORD_DEFAULT);
                    $update = $conn->prepare("UPDATE admins SET password_hash = ? WHERE username = ?");
                    if (!$update) {
                        $err = 'Database error (prepare update).';
                    } else {
                        $update->bind_param("ss", $newHash, $username);
                        if ($update->execute()) {
                            $success = 'Password changed successfully!';
                        } else {
                            $err = 'Failed to update password.';
                        }
                        $update->close();
                    }
                }
            }
            $conn->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Change Password • Restaurant Admin</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    .sidebar-active { @apply bg-indigo-700 text-white; }
    .sidebar-hover:hover { @apply bg-indigo-500 text-white; }
    #mobileMenu { transition: transform 0.3s ease-in-out; }
    #mobileMenu.closed { transform: translateX(-100%); }
  </style>
</head>
<body class="h-full bg-gray-100 flex font-sans">

  <div id="mobileMenu" class="fixed inset-y-0 left-0 z-50 w-64 bg-indigo-600 text-white flex flex-col shadow-2xl closed lg:hidden">
    <div class="p-6 border-b border-indigo-700">
      <h1 class="text-2xl font-bold flex items-center gap-3"><i class="fas fa-key"></i> Restaurant</h1>
    </div>
    <nav class="flex-1 px-4 py-6 space-y-1">
      <a href="admin.php" class="flex items-center gap-3 px-4 py-3 rounded-lg sidebar-hover transition"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
      <a href="admin_change_password.php" class="flex items-center gap-3 px-4 py-3 rounded-lg sidebar-active transition"><i class="fas fa-key"></i> Change Password</a>
    </nav>
    <div class="p-4 border-t border-indigo-700">
      <form action="admin_logout.php" method="post">
        <button type="submit" class="w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 py-3.5 rounded-lg font-medium shadow-lg transition">
          <i class="fas fa-sign-out-alt"></i> Logout
        </button>
      </form>
    </div>
  </div>

  <div class="flex-1 flex flex-col w-full">
    <header class="bg-white shadow-sm border-b border-gray-200 px-4 sm:px-8 py-4 flex justify-between items-center">
      <div class="flex items-center gap-4">
        <button id="menuToggle" class="lg:hidden text-gray-700 text-2xl"><i class="fas fa-bars"></i></button>
        <h2 class="text-2xl sm:text-3xl font-bold text-gray-800 flex items-center gap-3">
          <i class="fas fa-lock text-indigo-600"></i> Change Password
        </h2>
      </div>
    </header>

    <div class="flex flex-1 overflow-hidden">
      <aside class="hidden lg:flex lg:flex-col w-64 bg-indigo-600 text-white shadow-xl">
        <div class="p-6 border-b border-indigo-700">
          <h1 class="text-2xl font-bold flex items-center gap-3"><i class="fas fa-key"></i> Restaurant</h1>
          <p class="text-indigo-200 text-sm mt-1">Admin Panel</p>
        </div>
        <nav class="flex-1 px-4 py-6 space-y-1">
          <a href="admin.php" class="flex items-center gap-3 px-4 py-3 rounded-lg sidebar-hover transition"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
           <a href="admin_change_password.php" class="flex items-center gap-3 px-4 py-3 rounded-lg sidebar-active transition"><i class="fas fa-key"></i> Change Password</a>
        </nav>
        <div class="p-4 border-t border-indigo-700 mt-auto">
          <form action="admin_links_logout.php" method="post">
            <button type="submit" class="w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 py-3.5 rounded-lg font-medium shadow-lg transition">
              <i class="fas fa-sign-out-alt"></i> Logout
            </button>
          </form>
        </div>
      </aside>

      <main class="flex-1 p-4 sm:p-8 overflow-auto flex items-start justify-center bg-gray-50">
        <div class="w-full">
          <div class="bg-white rounded-2xl shadow-2xl p-8 sm:p-12 border border-gray-100">

            <div class="text-center mb-10">
              <div class="w-20 h-20 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center mx-auto shadow-2xl">
                <i class="fas fa-user-shield text-white text-4xl"></i>
              </div>
              <h3 class="text-3xl font-bold text-gray-800 mt-6">Update Your Password</h3>
              <p class="text-gray-500 mt-3 text-lg">Keep your account secure</p>
            </div>

            <form method="POST" class="space-y-7">
              <div>
                <label class="block text-lg font-semibold text-gray-700 mb-3"><i class="fas fa-lock mr-2 text-indigo-600"></i> Current Password</label>
                <input type="password" name="current_password" required autocomplete="current-password" class="w-full px-6 py-5 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-200 focus:border-indigo-500 text-lg shadow-sm" placeholder="••••••••">
              </div>
              <div>
                <label class="block text-lg font-semibold text-gray-700 mb-3"><i class="fas fa-key mr-2 text-green-600"></i> New Password</label>
                <input type="password" name="new_password" required autocomplete="new-password" class="w-full px-6 py-5 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-200 focus:border-indigo-500 text-lg shadow-sm" placeholder="Minimum 8 characters">
              </div>
              <div>
                <label class="block text-lg font-semibold text-gray-700 mb-3"><i class="fas fa-check-circle mr-2 text-blue-600"></i> Confirm New Password</label>
                <input type="password" name="confirm_password" required autocomplete="new-password" class="w-full px-6 py-5 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-200 focus:border-indigo-500 text-lg shadow-sm" placeholder="Repeat new password">
              </div>

              <button type="submit" class="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold py-5 rounded-xl shadow-xl transition transform hover:scale-105 active:scale-95 text-xl">
                <i class="fas fa-save mr-3"></i> Update Password
              </button>
            </form>

            <div class="mt-10 text-center">
              <a href="../admin.php" class="text-indigo-600 hover:text-indigo-800 font-semibold text-lg transition">Back to Dashboard</a>
            </div>
          </div>
        </div>
      </main>
    </div>

    <footer class="bg-white border-t border-gray-200 px-6 py-5 text-center text-gray-500 text-sm">
      © <?= date('Y') ?> TOMIK Payments • Secure Administration Panel
    </footer>
  </div>

  <div id="overlay" class="fixed inset-0 bg-black/60 z-40 hidden lg:hidden"></div>

  <!-- Уведомления -->
  <?php if ($err): ?>
  <script>
    Swal.fire({icon:'error', title:'Error', text:<?= json_encode($err) ?>, confirmButtonColor:'#6366f1'});
  </script>
  <?php endif; ?>

  <?php if ($success): ?>
  <script>
    Swal.fire({icon:'success', title:'Success!', text:<?= json_encode($success) ?>, timer:3500, timerProgressBar:true, confirmButtonColor:'#10b981'});
  </script>
  <?php endif; ?>
  <script>
    const menuToggle = document.getElementById('menuToggle');
    const mobileMenu = document.getElementById('mobileMenu');
    const overlay = document.getElementById('overlay');
    menuToggle?.addEventListener('click', () => {
      mobileMenu.classList.toggle('closed');
      overlay.classList.toggle('hidden');
    });
    overlay.addEventListener('click', () => {
      mobileMenu.classList.add('closed');
      overlay.classList.add('hidden');
    });
  </script>
  <?php if (!empty($show_demo_alert)): ?>
<script>
Swal.fire({
    icon: 'info',
    title: 'Demo Mode Active',
    html: '<strong>Password change is disabled</strong><br>in the public demo for security.',
    confirmButtonText: 'Understood',
    confirmButtonColor: '#6366f1',
    allowOutsideClick: false,
    timer: 6000,
    timerProgressBar: true
});
</script>
<?php endif; ?>
</body>
</html>
