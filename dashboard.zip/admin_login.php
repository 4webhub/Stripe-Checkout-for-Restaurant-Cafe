<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

ob_start();
session_start();
require 'config.php'; // DB config

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$username || !$password) {
        $error = "Please enter username and password";
    } else {
        $conn = new mysqli($host, $user, $pass, $db);
        if ($conn->connect_error) {
            die("DB connection failed: " . $conn->connect_error);
        }

        $stmt = $conn->prepare("SELECT password_hash FROM admins WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->bind_result($hash);
        if ($stmt->fetch()) {
            if (password_verify($password, $hash)) {
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_username'] = $username;
                header('Location: superadm/admin.php');
                exit;
            } else {
                $error = "Invalid username or password";
            }
        } else {
            $error = "Invalid username or password";
        }

        $stmt->close();
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Restaurant Admin • Login</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
</head>
<body class="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center px-4">

  <div class="w-full max-w-2xl">

    <div class="text-center mb-12">
      <div class="w-24 h-24 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-full flex items-center justify-center mx-auto shadow-2xl">
        <i class="fab fa-stripe text-white text-4xl"></i>
      </div>
      <h1 class="text-4xl font-bold text-gray-800 mt-6">Restaurant Admin</h1>
      <p class="text-gray-600 mt-2 text-lg">Secure Administration Panel</p>
    </div>


    <div class="bg-white/80 backdrop-blur-lg p-10 rounded-3xl shadow-2xl border border-white/20">
      <h2 class="text-3xl font-bold text-center text-gray-800 mb-10">Welcome Back</h2>

      <form method="post" id="loginForm" class="space-y-8">
        <div>
          <label for="username" class="block text-lg font-semibold text-gray-700 mb-3">
            Username
          </label>
          <input type="text" name="username" id="username" required autocomplete="username"
                 class="w-full px-6 py-5 text-lg rounded-xl border border-gray-300 
                        focus:ring-4 focus:ring-indigo-200 focus:border-indigo-600 
                        transition-all shadow-lg hover:shadow-xl"
                 placeholder="Enter your username" />
        </div>

        <div>
          <label for="password" class="block text-lg font-semibold text-gray-700 mb-3">
            Password
          </label>
          <input type="password" name="password" id="password" required autocomplete="current-password"
                 class="w-full px-6 py-5 text-lg rounded-xl border border-gray-300 
                        focus:ring-4 focus:ring-indigo-200 focus:border-indigo-600 
                        transition-all shadow-lg hover:shadow-xl"
                 placeholder="Enter your password" />
        </div>

        <button type="submit"
                class="w-full py-5 px-8 bg-gradient-to-r from-indigo-600 to-purple-600 
                       hover:from-indigo-700 hover:to-purple-700 text-white 
                       font-bold text-xl rounded-xl shadow-xl 
                       transition-all transform hover:scale-105 active:scale-95">
          Login
        </button>
      </form>

      <div class="mt-8 text-center">
        <p class="text-sm text-gray-500">
          © <?= date('Y') ?> Restaurant Payments • All rights reserved
        </p>
      </div>
    </div>
  </div>
<?php if (!empty($error)): ?>
<script>
  document.addEventListener('DOMContentLoaded', () => {
    Swal.fire({
      icon: 'error',
      title: 'Login Failed',
      text: <?= json_encode($error) ?>,
      confirmButtonColor: '#6366f1'
    });
  });
</script>
<?php endif; ?>
</body>
</html>
